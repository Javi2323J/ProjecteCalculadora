package ProjecteCalculadora;

public class MainCalculadora {
    public static void main(String[] args) {
        Calculadora c = new Calculadora();
        c.setVisible(true);
    }
}